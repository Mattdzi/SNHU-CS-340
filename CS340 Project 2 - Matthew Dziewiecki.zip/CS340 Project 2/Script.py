from pymongo import MongoClient
from bson.objectid import ObjectId

# CS340 Project 2 - Matthew Dziewiecki
#February 17th 2025

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password):
        """Initializes MongoDB connection with authentication."""
        self.username = username
        self.password = password
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 33974
        DB = 'AAC'
        COL = 'animals'
        #
        # Initialize Connection
        #
        self.client = MongoClient(f'mongodb://{username}:{password}@{HOST}:{PORT}/')
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]

# Complete this create method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
            if data:
                self.database.animals.insert_one(data) # data should be dictionary
                return True #Return the True bool value if the creation was successful
            else:
                return False #Return the False bool value if the creation was not successful
        else:
            raise Exception("Nothing to save, because data parameter is empty")
    
# Create method to implement the R in CRUD.
    def read(self, search={}):
        try:
            return list(self.collection.find(search, {"_id": 0}))  # Exclude '_id' from results
        except Exception as e:
            print(f"Error retrieving data: {e}")
            return []
            
# Create method to implement the U in CRUD
    def update(self, search, new_data):
        if search is not None:
            if search:
                updateResult = self.database.animals.update_many(search, {'$set' : new_data}) #Updating the searched data in the database
                return updateResult.modified_count #Return the number of changes in the database
        else: 
            raise Exception("There was an error while updating")
            
# Create method to implement the D in CRUD
    def delete(self, search):
        if search is not None: #If the search result is in the database
            deleteResult = self.collection.delete_many(search) #Delete the search result
            return deleteResult.deleted_count #Return the delected amount in the database
        else: 
            raise Exception("There was an error while deleting")



